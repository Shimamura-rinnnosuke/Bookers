Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  root :to => 'homes#top'
  get  "/books" => "todolists#new"
  post '/books' => 'todolists#create'
  get '/books/:id' => 'todolists#show', as: 'todolist'
  get '/books/:id/edit' => 'todolists#edit', as: 'edit_todolist'
  patch '/books/:id' => 'todolists#update', as: 'update_todolist'
  delete '/books/:id' => 'todolists#destroy', as: 'destroy_todolist'


end