class TodolistsController < ApplicationController
  def new
    @list = Book.new
    @lists = Book.all
  end

  def create
    # １. データを新規登録するためのインスタンス作成
    @list = Book.new(list_params)

    if @list.save

      redirect_to todolist_path(@list.id)
    else
      @lists = Book.all
      render :new
    end
    # ２. データをデータベースに保存するためのsaveメソッド実行


  end

  def show
    @list = Book.find(params[:id])
  end

  def edit
    @list = Book.find(params[:id])

  end

  def update
    list = Book.find(params[:id])
    list.update(list_params)
    redirect_to todolist_path(list.id)

  end

  def destroy
    list = Book.find(params[:id])
    list.destroy
    redirect_to "/books"
  end




  private
  # ストロングパラメータ
  def list_params
    params.require(:book).permit(:title, :body)
  end
end
